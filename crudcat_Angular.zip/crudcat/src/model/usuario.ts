export class Usuario {
    email: string;
    password: string;
    token:string;
}