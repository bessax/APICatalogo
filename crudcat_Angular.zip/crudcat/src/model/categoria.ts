export class Categoria {
    categoriaId: string;
    nome: string;
    imagemUrl: string;
}